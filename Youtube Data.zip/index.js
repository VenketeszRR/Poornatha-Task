const {google} = require('googleapis');
const MongoClient = require('mongodb').MongoClient;

const f = require('./constant')



//const client = new MongoClient(f.DB_URL, { useNewUrlParser: true, useUnifiedTopology: true });

// initialize the Youtube API library
const youtube = google.youtube({
  version: 'v3',
  auth:  f.API_KEY
});


//get top 10 recent video data about cricket
async function getVideoDetails() {
  const res = await youtube.search.list({
    part: 'id,snippet',
    q: 'cricket',
    maxResults: 10,
    order: 'date'
  })
  
  MongoClient.connect(f.DB_URL,{ useNewUrlParser: true, useUnifiedTopology: true }, function(err, db) {
    if (err) throw err;
    var dbo = db.db("Youtube");
    var n=res.data.items.length
    for(i=0;i<n;i++)
    {
      var singleVideo=res.data.items[i]
      var id = singleVideo.id.videoId;
      //videoId is used as _id to avoid duplicate entry to db
      myobj = {
        _id : id,
        publishedAt: singleVideo.snippet.publishedAt,
        channelId: singleVideo.snippet.channelId,
        title: singleVideo.snippet.title,
        description: singleVideo.snippet.descripton,
        thumbnails: [
          singleVideo.snippet.thumbnails.default.url,
          singleVideo.snippet.thumbnails.medium.url,
          singleVideo.snippet.thumbnails.high.url
        ],
        channelTitle: singleVideo.snippet.channelTitle,
      }
      //console.log(myobj)
      dbo.collection("Data").insertOne(myobj, function(err, res) {
        if (err)
        {
          if(err.code == 11000)
            console.log("Already exists")
          else
            throw err
        }
      });
    }
    
    //db.close();
  })
  
};

getVideoDetails()


var express = require('express');
var app = express();
var PORT = 3000;
  
// Without middleware
app.get('/', function(req, res){
  MongoClient.connect(f.DB_URL,{ useNewUrlParser: true, useUnifiedTopology: true }, function(err, db) {
    if (err) throw err;
    var dbo = db.db("Youtube");
    var mysort = { publishedAt: -1 };
    dbo.collection("Data").find().sort(mysort).toArray(function(err, result) {
      if (err) throw err;
      console.log(result)
      db.close();
      res.json(result)
    });
});
});
  
app.listen(PORT, function(err){
    if (err) console.log(err);
    console.log("Server listening on PORT", PORT);
});