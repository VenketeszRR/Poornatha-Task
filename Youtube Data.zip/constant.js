//change the value of api key and db url

const API_KEY = 'AIzaSyCYYFqB3DuWxf3RxlcXZlmQvpfC2Ob5x0Q'
const DB_URL = "mongodb://balaji:abcd1234@cluster0-shard-00-00.2zgg3.mongodb.net:27017,cluster0-shard-00-01.2zgg3.mongodb.net:27017,cluster0-shard-00-02.2zgg3.mongodb.net:27017/Youtube?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=true&w=majority";

module.exports = {API_KEY,DB_URL}